from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def index():
  return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
  return render_template('results.html', name = request.form['name'],   dojo_location=request.form['city'], favorite_language = request.form['language'], comments = request.form["comments"])

app.run(debug=True)